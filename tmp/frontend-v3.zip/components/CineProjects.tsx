
import React, { useState } from 'react';
import { ProductionProject } from '../types';

const initialProjects: ProductionProject[] = [
  { id: 'SF-092', title: 'Manifesto Residencial Matta', client: 'Lugasa Group', stage: 'Review', progress: 85, priority: 'Crítica', deadline: '28 Out', team: ['Vitor', 'Rodrigo'], thumbnail: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=400' },
  { id: 'SF-095', title: 'Brand Film Exotic', client: 'Sarto Imóveis', stage: 'Edição', progress: 60, priority: 'Normal', deadline: '05 Nov', team: ['Bia', 'Vitor'], thumbnail: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=80&w=400' },
  { id: 'SF-102', title: 'Documentário Corporate', client: 'Banco Legacy', stage: 'Roteiro', progress: 25, priority: 'Urgente', deadline: '30 Out', team: ['Rodrigo'], thumbnail: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=400' },
  { id: 'SF-108', title: 'Tour 360 High-End', client: 'Vértice Arq', stage: 'Captação', progress: 45, priority: 'Normal', deadline: '12 Nov', team: ['Caio', 'Rodrigo'], thumbnail: 'https://images.unsplash.com/photo-1449156001931-828320f3a002?auto=format&fit=crop&q=80&w=400' },
  { id: 'SF-110', title: 'Comercial Verão 25', client: 'Moda Loft', stage: 'Briefing', progress: 10, priority: 'Baixa', deadline: '20 Dez', team: ['Bia'], thumbnail: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=400' },
];

const stages = ['Briefing', 'Roteiro', 'Captação', 'Edição', 'Review'];

export const CineProjects: React.FC = () => {
  const [projects, setProjects] = useState<ProductionProject[]>(initialProjects);

  return (
    <div className="space-y-12 reveal active pb-20">
      {/* Module Header */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 border-b border-white/5 pb-10">
        <div className="space-y-3">
          <div className="inline-flex items-center gap-3 px-3 py-1 rounded-full bg-squad-blue/5 border border-squad-blue/20">
            <span className="material-symbols-outlined text-squad-blue text-[14px]">movie_edit</span>
            <span className="text-[9px] font-black text-squad-blue uppercase tracking-widest">SQUAD WORKFLOW // ACTIVE ENGINE</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold uppercase tracking-tighter text-white">
            Gestão de <span className="font-serif italic font-normal text-gray-500">Projetos</span>
          </h1>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="glass-card px-6 py-4 rounded-2xl flex items-center gap-4 bg-white/5">
            <div className="text-right">
              <p className="text-[9px] text-gray-500 font-black uppercase">Ativos agora</p>
              <p className="text-xs text-white font-bold">{projects.length} FILMES</p>
            </div>
            <div className="w-px h-8 bg-white/10"></div>
            <button className="text-squad-blue hover:text-white transition-colors">
              <span className="material-symbols-outlined">filter_list</span>
            </button>
          </div>
          <button className="glass-card px-8 py-4 rounded-full text-[10px] font-black uppercase tracking-widest text-white hover:bg-white hover:text-black transition-all">
            Novo Workflow
          </button>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="flex gap-6 overflow-x-auto pb-8 scrollbar-hide min-h-[700px]">
        {stages.map((stage) => (
          <div key={stage} className="flex-shrink-0 w-80 space-y-6">
            <div className="flex items-center justify-between px-4 pb-2 border-b border-white/5">
              <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{stage}</h3>
              <span className="text-[10px] font-bold text-white/40">{projects.filter(p => p.stage === stage).length}</span>
            </div>

            <div className="space-y-4">
              {projects.filter(p => p.stage === stage).map((project) => (
                <div 
                  key={project.id} 
                  className="glass-card p-6 rounded-[2rem] border-white/5 hover:border-squad-blue/30 transition-all duration-500 group cursor-pointer"
                >
                  <div className="relative aspect-video rounded-2xl overflow-hidden mb-5 grayscale group-hover:grayscale-0 transition-all duration-700">
                    <img src={project.thumbnail} alt={project.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s]" />
                    <div className="absolute top-3 right-3">
                       <span className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest border ${
                         project.priority === 'Crítica' ? 'bg-red-500/80 border-red-500 text-white' : 
                         project.priority === 'Urgente' ? 'bg-orange-500/20 border-orange-500/50 text-orange-500' : 
                         'bg-black/60 border-white/10 text-white'
                       }`}>
                         {project.priority}
                       </span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="text-[11px] font-black text-squad-blue uppercase tracking-widest mb-1">{project.client}</h4>
                      <h3 className="text-sm font-bold text-white uppercase tracking-tight line-clamp-2 leading-tight">{project.title}</h3>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-[8px] font-black uppercase tracking-widest text-gray-500">
                        <span>Workflow</span>
                        <span className="text-white">{project.progress}%</span>
                      </div>
                      <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-squad-blue shadow-[0_0_10px_#00A3D3]" 
                          style={{ width: `${project.progress}%` }}
                        ></div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-white/5">
                      <div className="flex -space-x-2">
                        {project.team.map((member, i) => (
                          <div key={i} className="w-7 h-7 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-[8px] font-black text-white hover:z-10 transition-all">
                            {member[0]}
                          </div>
                        ))}
                        <button className="w-7 h-7 rounded-full bg-squad-blue/10 border border-squad-blue/20 flex items-center justify-center text-squad-blue">
                          <span className="material-symbols-outlined text-[10px]">add</span>
                        </button>
                      </div>
                      <div className="text-right">
                        <p className="text-[8px] text-gray-600 uppercase font-black">Entrega</p>
                        <p className="text-[10px] text-white font-bold">{project.deadline}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              <button className="w-full py-8 border-2 border-dashed border-white/5 rounded-[2rem] text-gray-700 hover:border-squad-blue/20 hover:text-gray-400 transition-all flex flex-col items-center justify-center gap-2">
                <span className="material-symbols-outlined">add</span>
                <span className="text-[9px] font-black uppercase tracking-widest">Novo em {stage}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
      
      {/* Summary Footer */}
      <div className="glass-card p-10 rounded-[3rem] border-white/5 bg-gradient-to-r from-[#050505] to-black flex flex-col md:flex-row items-center justify-between gap-10">
        <div className="flex items-center gap-6">
           <div className="w-16 h-16 rounded-full border border-squad-blue/20 flex items-center justify-center bg-squad-blue/5">
             <span className="material-symbols-outlined text-squad-blue text-3xl animate-pulse">speed</span>
           </div>
           <div>
             <h4 className="text-xl font-bold uppercase tracking-tight text-white">Velocidade de Produção</h4>
             <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest">Média de 14 dias por entrega High-End</p>
           </div>
        </div>
        <div className="flex items-center gap-12">
          <div className="text-center">
            <span className="text-3xl font-bold text-white">87%</span>
            <p className="text-[9px] text-gray-600 font-black uppercase">On-Time Rate</p>
          </div>
          <div className="text-center">
            <span className="text-3xl font-bold text-squad-blue">12</span>
            <p className="text-[9px] text-gray-600 font-black uppercase">Reviews pendentes</p>
          </div>
          <button className="px-10 py-5 bg-white text-black rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-squad-blue hover:text-white transition-all">
            Relatório Operacional
          </button>
        </div>
      </div>
    </div>
  );
};
