
export type ModuleType = 'dashboard' | 'crm' | 'projects' | 'financial' | 'ai-agents' | 'settings';

export interface Lead {
  id: string;
  company: string;
  decisor: string;
  value: string;
  score: number;
  status: 'Inbound' | 'Qualificação' | 'Proposta' | 'Fechado';
}

export interface ProductionProject {
  id: string;
  title: string;
  client: string;
  stage: 'Briefing' | 'Roteiro' | 'Captação' | 'Edição' | 'Review';
  progress: number;
  priority: 'Baixa' | 'Normal' | 'Urgente' | 'Crítica';
  thumbnail?: string;
  deadline: string;
  team: string[];
}

export interface ProjectTask {
  id: string;
  projectId: string;
  title: string;
  assignee: string;
  assigneeAvatar?: string;
  status: 'Pendente' | 'Em Andamento' | 'Concluído';
  priority: 'Baixa' | 'Normal' | 'Urgente' | 'Crítica';
  dueDate: string;
}

export interface AITask {
  agent: 'SDR' | 'PM' | 'QA' | 'Fin';
  message: string;
  timestamp: string;
  actionRequired: boolean;
}

export interface Experience {
  id: string;
  role: string;
  company: string;
  period: string;
  type: string;
}
