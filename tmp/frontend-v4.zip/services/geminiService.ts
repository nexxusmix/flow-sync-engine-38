
import { GoogleGenAI } from "@google/genai";

export const askPoloAI = async (userMessage: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userMessage,
      config: {
        systemInstruction: `Você é o Consultor Virtual da SQUAD FILM.
        Sua personalidade é técnica, direta, mas inspiradora.
        Você é um mestre em produção cinematográfica voltada para o mercado imobiliário e corporativo.
        Seu foco é explicar como a SQUAD FILM utiliza luz, enquadramento e edição de ritmo para criar filmes que não apenas mostram um espaço, mas vendem um estilo de vida.
        Palavras-chave: Squad Film, Narrativa Visual, Lançamentos, High-end, Cinema Corporativo.
        Use uma linguagem que remeta ao mundo audiovisual profissional.`,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Falha na conexão com o estúdio. Por favor, tente novamente.";
  }
};
