
import React from 'react';
import { Experience } from '../types';

const experiences: Experience[] = [
  {
    id: '1',
    role: 'Product Designer',
    company: 'GreenLeaf Co',
    period: '2023 - Present',
    type: 'Freelance'
  },
  {
    id: '2',
    role: 'UrbanFit Studio',
    company: 'UrbanFit',
    period: '2021 - 2023',
    type: 'UX/UI Designer'
  },
  {
    id: '3',
    role: 'PixelCrafters',
    company: 'PixelCrafters',
    period: '2019 - 2021',
    type: 'Graphic Designer'
  }
];

export const ExperienceSection: React.FC = () => {
  return (
    <section className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
      <div className="bg-surface-dark border border-border-dark rounded-3xl p-8 md:p-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 blur-[80px] rounded-full pointer-events-none"></div>
        <div className="relative z-10">
          <div className="w-20 h-20 rounded-full overflow-hidden mb-6 border-2 border-white/10">
            <img 
              alt="Profile" 
              className="w-full h-full object-cover grayscale" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCWO7-LZwvqhpXJAarn1UIjZYrwHb28tR5_306AxrmMdxEFHbqI29ZPFGdQ-wRXMlY027Z4Y4SBPqbMHho877qnLQQNkgi3nojKSNp2ONOCDTUyBTojMCdwOWy5kjgA2qRzGRzztBcAIYI-l8A9EIH240zq8wOtyS2NTN2KIs1oY_dAf4g7kzp0GmYLkt48-FBpLNUPzSPTH4YkVdNtUZb0IGGbOcUek3CxQxNCnrB13OuYB5tiVb8x9FX7jQ_WTQOlTTMoRCJz-TDt" 
            />
          </div>
          <h2 className="text-3xl md:text-4xl font-semibold text-white mb-2">Hello I am Johan Beker</h2>
          <p className="text-gray-400 mb-8">UI/UX Interaction Designer Based in Berlin.</p>
          <div className="flex gap-4 mb-10">
            {['X', 'photo_camera', 'language'].map((icon, idx) => (
              <a 
                key={idx}
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors" 
                href="#"
              >
                {icon.length === 1 ? <span className="font-bold text-sm">{icon}</span> : <span className="material-symbols-outlined text-sm">{icon}</span>}
              </a>
            ))}
          </div>
          <a className="inline-flex items-center justify-center px-6 py-3 bg-white text-black rounded-full text-sm font-medium hover:opacity-90 transition-opacity w-full sm:w-auto" href="#">
            Connect with me
          </a>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        {experiences.map((exp) => (
          <div key={exp.id} className="bg-surface-dark border border-border-dark rounded-3xl p-6 flex justify-between items-center group hover:border-gray-600 transition-colors">
            <div>
              <p className="text-sm text-gray-400 mb-1">{exp.type}</p>
              <h4 className="text-lg font-medium text-white">{exp.role}</h4>
            </div>
            <div className="text-right">
              <span className="text-sm font-semibold text-white block">{exp.company}</span>
              <span className="text-xs text-gray-500">{exp.period}</span>
            </div>
          </div>
        ))}
        
        {/* Footer info embedded in grid */}
        <div className="mt-auto pt-4 flex items-center justify-between px-2">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-white">stars</span>
            <span className="font-bold text-white text-xl font-serif italic">Polo</span>
          </div>
          <p className="text-xs text-gray-600">© 2024 All Rights Reserved.</p>
        </div>
      </div>
    </section>
  );
};
