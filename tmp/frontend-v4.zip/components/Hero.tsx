
import React from 'react';

export const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex flex-col justify-center items-start pt-20 preserve-3d overflow-hidden">
      <div className="max-w-7xl w-full z-10 reveal active">
        <div className="inline-flex items-center gap-4 px-6 py-2.5 rounded-full border border-white/5 bg-white/5 backdrop-blur-2xl mb-14 animate-float shadow-2xl">
          <span className="w-2.5 h-2.5 rounded-full bg-squad-blue shadow-[0_0_15px_#00A3D3]"></span>
          <span className="text-[11px] font-black text-white/80 uppercase tracking-[0.6em]">Estética • Desejo • Resultado</span>
        </div>

        <div className="preserve-3d">
          <h1 className="text-[10rem] md:text-[14rem] lg:text-[18rem] font-sans font-extrabold leading-[0.72] tracking-tighter text-white uppercase select-none mb-24 drop-shadow-2xl">
            Better <br />
            <span className="font-serif italic font-normal text-squad-blue lowercase tracking-normal block transform translate-x-4">Filmmaker</span>
          </h1>
        </div>

        <div className="flex flex-col lg:flex-row items-start lg:items-end justify-between gap-16 w-full mt-10">
          <div className="max-w-xl space-y-8">
            <p className="text-gray-400 text-2xl leading-relaxed font-medium tracking-tight border-l-2 border-squad-blue/30 pl-8">
              Onde a luz esculpe a arquitetura e o cinema define o valor. Criamos narrativas viscerais para ativos imobiliários de <span className="text-white">alto luxo</span>.
            </p>
          </div>
          
          <div className="flex items-center gap-8">
            <button className="group relative px-14 py-8 rounded-3xl bg-white/5 border border-white/10 text-white text-[12px] font-black uppercase tracking-[0.4em] overflow-hidden transition-all hover:border-squad-blue/50">
              <span className="relative z-10">Showreel 2024</span>
              <div className="absolute inset-0 bg-white translate-y-full group-hover:translate-y-0 transition-transform duration-700 ease-out"></div>
              <span className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 text-black z-20 transition-opacity font-black">Showreel 2024</span>
            </button>
            <button className="px-14 py-8 rounded-3xl bg-squad-blue text-white text-[12px] font-black uppercase tracking-[0.4em] hover:scale-105 active:scale-95 transition-all shadow-[0_25px_70px_-15px_rgba(0,163,211,0.6)]">
              Contratar
            </button>
          </div>
        </div>
      </div>

      {/* Static 3D Depth Elements with Autonomic Float */}
      <div className="absolute top-[15%] right-[2%] hidden xl:block preserve-3d animate-float" style={{ animationDelay: '-2s' }}>
        <div className="glass-card p-12 rounded-[4rem] w-[360px] shadow-[0_100px_100px_-50px_rgba(0,0,0,0.8)] rotate-12 border-squad-blue/10 bg-black/40 backdrop-blur-3xl">
          <div className="flex gap-2 mb-8">
            {[1,2,3,4,5].map(i => <span key={i} className="material-symbols-outlined text-squad-blue text-sm">star</span>)}
          </div>
          <p className="text-white text-2xl font-serif italic mb-10 leading-snug">"Elevamos nosso VGV drasticamente através do olhar da Squad."</p>
          <div className="flex items-center gap-5">
             <div className="w-12 h-12 rounded-full bg-gradient-to-br from-squad-blue/40 to-white/20"></div>
             <span className="text-[11px] text-gray-500 font-black uppercase tracking-[0.2em]">Diretoria Lugasa</span>
          </div>
        </div>
      </div>

      <div className="absolute bottom-[20%] right-[15%] hidden xl:block preserve-3d animate-float" style={{ animationDelay: '-5s' }}>
        <div className="glass-card p-12 rounded-[4rem] w-[380px] shadow-[0_100px_100px_-50px_rgba(0,0,0,0.8)] -rotate-6 border-white/5 bg-black/40 backdrop-blur-3xl">
          <p className="text-gray-400 text-xl font-serif italic mb-8 leading-snug">"A SQUAD entrega o sentimento de exclusividade antes mesmo da primeira pedra."</p>
          <div className="flex justify-end">
            <span className="text-[11px] text-squad-blue font-black uppercase tracking-[0.2em]">Sarto Luxury Broker</span>
          </div>
        </div>
      </div>

      <div className="absolute top-1/2 left-0 -translate-y-1/2 opacity-[0.03] pointer-events-none select-none">
        <span className="text-[50rem] font-black text-white leading-none">SF</span>
      </div>
    </section>
  );
};
