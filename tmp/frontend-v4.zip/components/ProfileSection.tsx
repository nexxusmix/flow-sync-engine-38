
import React from 'react';

const experiences = [
  { company: 'SQUAD Film', role: 'Chief Visual Officer', period: '2023 - ATUAL', type: 'CO-FOUNDER', color: 'text-squad-blue' },
  { company: 'Legacy Studio', role: 'Art Director', period: '2021 - 2023', type: 'GLOBAL', color: 'text-white' },
  { company: 'Cannes Lions', role: 'Shortlist Editor', period: '2020 - 2021', type: 'AWARDS', color: 'text-white' }
];

export const ProfileSection: React.FC = () => {
  return (
    <section id="manifesto" className="py-32 grid grid-cols-1 lg:grid-cols-2 gap-12 items-stretch reveal">
      {/* Immersive Profile Card */}
      <div className="bg-[#040404] border border-white/5 rounded-[3.5rem] p-16 flex flex-col justify-between relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-squad-blue/10 blur-[150px] rounded-full group-hover:scale-125 transition-transform duration-1000"></div>
        <div className="absolute -left-20 -bottom-20 w-64 h-64 bg-white/5 blur-[100px] rounded-full"></div>
        
        <div className="relative z-10">
          <div className="relative w-32 h-32 mb-12">
            <div className="absolute inset-0 bg-squad-blue rounded-full animate-ping opacity-20 group-hover:opacity-40"></div>
            <div className="relative w-full h-full rounded-full overflow-hidden border-2 border-white/10 grayscale group-hover:grayscale-0 transition-all duration-1000">
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400" 
                alt="Director" 
                className="w-full h-full object-cover scale-110 group-hover:scale-100 transition-transform duration-1000"
              />
            </div>
          </div>

          <div className="inline-flex items-center gap-2 mb-6 px-4 py-1.5 rounded-full border border-green-500/20 bg-green-500/5">
             <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
             <span className="text-[10px] font-black text-green-500/80 uppercase tracking-widest">Disponível para Projetos</span>
          </div>
          
          <h2 className="text-6xl md:text-7xl font-extrabold tracking-tighter text-white mb-8 uppercase leading-[0.9]">
            Rodrigo <br /> <span className="text-transparent bg-clip-text bg-gradient-to-r from-squad-blue to-white/40">Squad</span>
          </h2>
          
          <p className="text-gray-400 text-xl mb-12 max-w-sm font-medium leading-relaxed">
            Diretor de cena focado em capturar a alma de grandes obras arquitetônicas.
          </p>
          
          <div className="flex gap-4 mb-12">
            {[
              { icon: 'X', label: 'X', link: '#' },
              { icon: 'camera', label: 'Instagram', link: '#' },
              { icon: 'play_circle', label: 'Vimeo', link: '#' }
            ].map((social, idx) => (
              <a 
                key={idx}
                href={social.link}
                className="w-14 h-14 rounded-full border border-white/10 bg-white/5 flex items-center justify-center text-white hover:bg-white hover:text-black hover:border-white transition-all duration-500"
              >
                {social.icon === 'X' ? <span className="text-sm font-black">X</span> : <span className="material-symbols-outlined text-2xl">{social.icon}</span>}
              </a>
            ))}
          </div>
        </div>

        <button className="relative z-10 w-full sm:w-max px-12 py-6 bg-white text-black rounded-full text-[11px] font-black uppercase tracking-[0.3em] hover:bg-squad-blue hover:text-white transition-all duration-500 shadow-2xl">
          Reservar Consultoria
        </button>
      </div>

      {/* Experience & Vision */}
      <div className="flex flex-col gap-4 py-4">
        <div className="mb-12 space-y-4">
           <span className="text-xs font-black text-squad-blue uppercase tracking-[0.5em]">Legado</span>
           <h3 className="text-4xl font-serif italic text-white/80">Trajetória e Impacto</h3>
        </div>

        {experiences.map((exp, idx) => (
          <div key={idx} className="group bg-[#040404] border border-white/5 rounded-[2.5rem] p-10 flex justify-between items-center hover:border-squad-blue/40 hover:bg-[#060606] transition-all duration-700">
            <div className="space-y-2">
              <span className="text-[10px] text-gray-600 uppercase tracking-[0.2em] font-black">{exp.type}</span>
              <h4 className={`text-2xl font-bold ${exp.color} transition-colors group-hover:text-white`}>{exp.role}</h4>
              <p className="text-sm text-gray-500 font-medium group-hover:text-gray-400">{exp.company}</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-gray-600 uppercase tracking-[0.3em] font-bold block mb-2">{exp.period}</span>
              <div className="w-10 h-px bg-white/10 group-hover:w-16 group-hover:bg-squad-blue transition-all ml-auto"></div>
            </div>
          </div>
        ))}
        
        <div className="mt-auto flex items-end justify-between px-8 py-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="squad-logo-text text-2xl text-white">SQUAD</span>
              <span className="text-squad-blue film-italic text-xl">///FILM</span>
            </div>
            <p className="text-[9px] text-gray-600 uppercase tracking-[0.4em] font-black">Powered by Creative Excellence</p>
          </div>
          <div className="text-right opacity-30">
            <span className="material-symbols-outlined text-6xl animate-spin-slow">star</span>
          </div>
        </div>
      </div>
    </section>
  );
};
