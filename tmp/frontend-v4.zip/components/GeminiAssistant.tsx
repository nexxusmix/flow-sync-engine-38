
import React, { useState, useRef, useEffect } from 'react';
import { askPoloAI } from '../services/geminiService';

interface Message {
  role: 'user' | 'ai';
  content: string;
}

export const GeminiAssistant: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  // Updated initial message to maintain SQUAD FILM brand consistency and match the service persona
  const [messages, setMessages] = useState<Message[]>([
    { role: 'ai', content: "Olá! Sou o Polo AI, seu assistente da SQUAD FILM. Como posso ajudar você hoje?" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setInput('');
    setLoading(true);

    const aiResponse = await askPoloAI(userMsg);
    setMessages(prev => [...prev, { role: 'ai', content: aiResponse || '' }]);
    setLoading(false);
  };

  return (
    <div className="fixed bottom-24 right-8 z-50 w-full max-w-[360px] sm:max-w-[400px] glass-card rounded-3xl shadow-2xl overflow-hidden border border-white/10 flex flex-col h-[500px]">
      <div className="p-4 bg-white/5 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="material-symbols-outlined text-white">auto_awesome</span>
          <span className="font-semibold">Polo Assistant</span>
        </div>
        <button onClick={onClose} className="hover:text-gray-400">
          <span className="material-symbols-outlined">close</span>
        </button>
      </div>
      
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] px-4 py-2 rounded-2xl text-sm ${
              msg.role === 'user' ? 'bg-white text-black' : 'bg-surface-dark border border-white/10 text-gray-300'
            }`}>
              {msg.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-surface-dark border border-white/10 px-4 py-2 rounded-2xl">
              <span className="flex gap-1">
                <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce"></span>
                <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce delay-75"></span>
                <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce delay-150"></span>
              </span>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-white/10 bg-black/40">
        <div className="flex gap-2">
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask something..."
            className="flex-1 bg-white/5 border border-white/10 rounded-full px-4 py-2 text-sm focus:outline-none focus:border-white/20"
          />
          <button 
            onClick={handleSend}
            disabled={loading}
            className="w-10 h-10 bg-white text-black rounded-full flex items-center justify-center disabled:opacity-50"
          >
            <span className="material-symbols-outlined text-sm">send</span>
          </button>
        </div>
      </div>
    </div>
  );
};
