
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="pt-32 pb-16 border-t border-white/5 relative z-10 bg-black">
      <div className="max-w-[1600px] mx-auto flex flex-col lg:flex-row justify-between items-center gap-12">
        {/* Profile Info Inspired by Reference */}
        <div className="flex items-center gap-6 group">
          <div className="w-16 h-16 rounded-full overflow-hidden border border-white/10 grayscale group-hover:grayscale-0 transition-all duration-700">
            <img 
              alt="Rodrigo Squad Profile" 
              className="w-full h-full object-cover" 
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200" 
            />
          </div>
          <div>
            <h4 className="text-base font-black text-white uppercase tracking-tight">Rodrigo Squad</h4>
            <p className="text-[10px] text-gray-500 uppercase tracking-[0.2em] font-bold">Chief Design & Film Officer</p>
          </div>
        </div>

        {/* Social Navigation */}
        <div className="flex items-center gap-10">
          {['Twitter', 'Instagram', 'Vimeo', 'LinkedIn'].map(link => (
            <a 
              key={link}
              href="#" 
              className="text-[11px] text-gray-500 hover:text-squad-blue transition-all duration-500 uppercase tracking-[0.3em] font-black"
            >
              {link}
            </a>
          ))}
        </div>

        {/* Copyright & Branding */}
        <div className="flex flex-col items-end gap-2 text-right">
          <div className="flex items-center gap-3">
             <span className="text-[11px] text-gray-600 font-black uppercase tracking-[0.4em]">© 2024 SQUAD FILM</span>
             <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
             <span className="text-[11px] text-gray-600 font-black uppercase tracking-[0.4em]">Creative Studio Global</span>
          </div>
          <p className="text-[9px] text-gray-800 uppercase tracking-[0.2em] font-bold">Estética • Desejo • Resultado</p>
        </div>
      </div>
    </footer>
  );
};
