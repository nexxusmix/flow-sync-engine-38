
import React, { useState } from 'react';

const categories = [
  { id: 'all', label: 'Todos os Filmes' },
  { id: 'luxury', label: 'Imobiliário de Luxo' },
  { id: 'branding', label: 'Filmes de Marca' },
  { id: 'cinematic', label: 'Narrativas' },
];

const projects = [
  {
    id: '01',
    title: 'Horizonte V',
    subtitle: 'Manifesto Arquitetônico',
    tag: 'Luxo',
    category: 'luxury',
    imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1600',
    featured: true
  },
  {
    id: '02',
    title: 'Urban Soul',
    subtitle: 'Ruptura Urbana',
    tag: 'Editorial',
    category: 'cinematic',
    imageUrl: 'https://images.unsplash.com/photo-1449156001931-828320f3a002?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: '03',
    title: 'Squad Core',
    subtitle: 'Post-Studio Workflow',
    tag: 'Sistema',
    category: 'branding',
    isMockup: true,
  },
  {
    id: '04',
    title: 'The Peak',
    subtitle: 'Lançamento Sky-High',
    tag: 'Imobiliário',
    category: 'luxury',
    imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1200',
  }
];

export const ProjectGrid: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('all');

  const filteredProjects = activeCategory === 'all' 
    ? projects 
    : projects.filter(p => p.category === activeCategory);

  return (
    <section id="projetos" className="py-48 relative z-10">
      <div className="absolute top-0 left-0 w-full opacity-[0.02] pointer-events-none select-none marquee-container mb-40">
        <div className="marquee-content text-[18rem] font-black uppercase tracking-tighter text-white">
          SQUAD FILM • HIGH END • CINEMA • LUXURY • SQUAD FILM • HIGH END • CINEMA • LUXURY • 
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-24">
        <aside className="lg:w-80 flex-shrink-0">
          <div className="sticky top-48 space-y-20">
            <div className="reveal">
              <h2 className="text-[12px] text-squad-blue uppercase tracking-[0.6em] font-black mb-14 flex items-center gap-5">
                <span className="w-10 h-px bg-squad-blue"></span>
                Arquivo
              </h2>
              <div className="flex flex-col items-start gap-8">
                {categories.map((cat) => (
                  <button 
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    className={`group text-base font-black flex items-center gap-6 transition-all duration-700 ${activeCategory === cat.id ? 'text-white' : 'text-gray-700 hover:text-white'}`}
                  >
                    <div className={`relative w-5 h-5 rounded-sm border-2 transition-all duration-700 ${activeCategory === cat.id ? 'bg-squad-blue border-squad-blue rotate-45 scale-125' : 'border-white/10 group-hover:border-white/40'}`}></div>
                    <span className="uppercase tracking-[0.3em] text-[11px]">{cat.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-14 border-t border-white/5 reveal" style={{ transitionDelay: '300ms' }}>
              <div className="glass-card p-8 rounded-[2.5rem] bg-white/5 space-y-6">
                <div className="flex justify-between items-center text-[10px] font-black text-gray-600 uppercase tracking-[0.4em]">
                  <span>Status</span>
                  <span className="text-squad-blue animate-pulse">Online</span>
                </div>
                <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-squad-blue w-2/3"></div>
                </div>
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-[0.2em]">
                  {filteredProjects.length} / {projects.length} FILMES CARREGADOS
                </p>
              </div>
            </div>
          </div>
        </aside>

        <div className="flex-grow space-y-64">
          {filteredProjects.map((project, idx) => (
            <div 
              key={project.id} 
              className="group reveal preserve-3d"
              style={{ transitionDelay: `${idx * 200}ms` }}
            >
              <div className="relative w-full transition-all duration-1000 ease-out group-hover:translate-z-[80px]">
                <div className={`relative ${project.featured ? 'aspect-[21/9]' : 'aspect-[16/9]'} w-full overflow-hidden rounded-[4rem] bg-surface-dark border border-white/5 shadow-[0_60px_120px_-30px_rgba(0,0,0,0.9)] transition-all duration-1000 group-hover:scale-[1.01]`}>
                  
                  {project.isMockup ? (
                    <div className="absolute inset-0 bg-gradient-to-br from-[#080808] to-black p-24 flex items-center justify-center overflow-hidden">
                      <div className="w-full h-full max-w-5xl bg-[#020202] rounded-[3rem] border border-white/10 shadow-2xl relative">
                        <div className="p-20 space-y-12">
                          <div className="flex items-center gap-8">
                            <span className="material-symbols-outlined text-squad-blue text-6xl animate-pulse">hub</span>
                            <span className="text-white font-black text-5xl tracking-tighter uppercase">Squad Core</span>
                          </div>
                          <div className="space-y-6 opacity-5">
                            <div className="h-4 w-full bg-white rounded-full"></div>
                            <div className="h-4 w-3/4 bg-white rounded-full"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <img 
                      alt={project.title} 
                      className="w-full h-full object-cover transition-transform duration-[2.5s] group-hover:scale-110" 
                      src={project.imageUrl} 
                    />
                  )}

                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/30 opacity-40 group-hover:opacity-60 transition-opacity duration-700"></div>

                  {project.featured && (
                    <div className="absolute top-12 left-12">
                      <div className="glass-card px-10 py-5 rounded-full flex items-center gap-4 border-squad-blue/20 bg-black/60">
                        <span className="relative flex h-3 w-3">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-squad-blue opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-3 w-3 bg-squad-blue"></span>
                        </span>
                        <span className="text-[12px] font-black uppercase tracking-[0.5em] text-white">CINE MASTERPIECE</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-16 flex flex-col md:flex-row justify-between items-end gap-12 px-10">
                  <div className="max-w-3xl">
                    <span className="text-[11px] font-black text-squad-blue mb-5 block uppercase tracking-[0.7em]">SF ARCHIVE — {project.id}</span>
                    <h3 className="text-7xl md:text-9xl font-extrabold text-white mb-6 uppercase tracking-tighter transition-all duration-700 group-hover:tracking-normal">{project.title}</h3>
                    <p className="text-3xl md:text-4xl text-gray-500 font-serif italic group-hover:text-white transition-colors duration-700">{project.subtitle}</p>
                  </div>
                  <div className="flex flex-col items-end gap-8">
                    <span className="px-14 py-6 rounded-3xl border border-white/10 text-[12px] text-white font-black uppercase tracking-[0.5em] group-hover:bg-squad-blue group-hover:border-squad-blue transition-all duration-700">
                      Explorar Projeto
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
