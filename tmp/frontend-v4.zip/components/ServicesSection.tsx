
import React from 'react';

const services = [
  {
    num: '01',
    title: 'Filmes',
    desc: 'Criamos filmes que vendem imóveis. Da concepção à entrega, cada frame é pensado para transformar empreendimentos em objetos de desejo.'
  },
  {
    num: '02',
    title: 'Fotos',
    desc: 'Capturamos a essência de cada projeto em imagens que respiram sofisticação. Fotos que contam histórias e despertam emoções.'
  },
  {
    num: '03',
    title: 'Marketing',
    desc: 'Estratégias de marketing digital completas para o mercado imobiliário. Do branding ao social media, construímos marcas que vendem.'
  },
  {
    num: '04',
    title: 'Tecnologia & Interatividade',
    desc: 'Tours virtuais, realidade aumentada e tecnologias interativas que encantam e engajam o cliente final.'
  }
];

export const ServicesSection: React.FC = () => {
  return (
    <section id="serviços" className="py-24 border-t border-white/5">
      <div className="flex flex-col md:flex-row justify-between mb-20 gap-8">
        <div className="space-y-4">
          <h2 className="text-xs uppercase tracking-[0.3em] text-gray-500 font-bold">© SQUAD Film™ / SERVICES (SF® — 04)</h2>
          <h3 className="text-4xl md:text-5xl font-serif italic text-gray-300">Serviços (2026)</h3>
        </div>
        <div className="flex flex-wrap gap-6 text-xs font-bold text-gray-500 uppercase tracking-widest self-end">
          <span>Cinematográfico</span>
          <span>Estratégico</span>
          <span>Interatividade</span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {services.map((s) => (
          <div key={s.num} className="glass-card p-10 rounded-3xl border border-white/5 hover:border-white/20 transition-all group">
            <span className="text-4xl font-display font-medium text-gray-700 group-hover:text-white transition-colors mb-8 block">{s.num}</span>
            <h4 className="text-2xl font-bold mb-6">{s.title}</h4>
            <p className="text-gray-400 text-sm leading-relaxed">{s.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
};
