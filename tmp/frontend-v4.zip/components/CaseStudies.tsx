
import React from 'react';

const cases = [
  {
    title: 'Casa Lago // Lugasa',
    desc: 'Sofisticação à beira do Lago JK. Filme que traduz o conceito de viver bem: arquitetura contemporânea, natureza e tecnologia.',
    img: 'https://images.unsplash.com/photo-1449156001931-828320f3a002?auto=format&fit=crop&q=80&w=800'
  },
  {
    title: 'Fazenda da Matta // Haras',
    desc: 'A história de quem realizou o sonho de morar em um haras. Depoimento autêntico que transforma experiência em argumento.',
    img: 'https://images.unsplash.com/photo-1534353436294-0dbd4bdac845?auto=format&fit=crop&q=80&w=800'
  },
  {
    title: 'Sarto Imóveis // Exotic',
    desc: 'Quando imóveis de luxo encontram carros exóticos. Aftermovie que captura a essência de um lifestyle exclusivo.',
    img: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=80&w=800'
  }
];

export const CaseStudies: React.FC = () => {
  return (
    <section className="py-24 border-t border-white/5">
      <div className="mb-16">
        <span className="text-xs font-mono text-gray-500 mb-4 block">© Visual Project's (SF® — 06)</span>
        <h2 className="text-4xl font-serif italic text-white">Creative Notes</h2>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {cases.map((c, i) => (
          <div key={i} className="group cursor-pointer">
            <div className="aspect-[16/10] overflow-hidden rounded-2xl mb-6 grayscale group-hover:grayscale-0 transition-all">
              <img src={c.img} alt={c.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
            </div>
            <h4 className="text-xl font-bold mb-3">{c.title}</h4>
            <p className="text-gray-400 text-sm leading-relaxed mb-4">{c.desc}</p>
            <div className="w-8 h-[1px] bg-white/20 group-hover:w-full transition-all"></div>
          </div>
        ))}
      </div>
    </section>
  );
};
