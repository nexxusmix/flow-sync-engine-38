
import React, { useState } from 'react';
import { ProjectTask } from '../types';

const stats = [
  { label: 'Pipeline Ativo', value: 'R$ 840k', detail: '+15.2%', icon: 'insights', color: 'text-squad-blue' },
  { label: 'Projetos em Workflow', value: '12', detail: '87% On-time', icon: 'schedule', color: 'text-white' },
  { label: 'Inadimplência', value: '0.42%', detail: 'Low Risk', icon: 'shield', color: 'text-green-500' },
  { label: 'Tokens IA', value: '1.2M', detail: 'Consumo Mensal', icon: 'memory', color: 'text-purple-400' },
];

const projects = [
  { id: 'SF-092', title: 'Manifesto Matta', client: 'Lugasa Group', stage: 'Review 4K', progress: 85, priority: 'Crítica', deadline: '28 Out', dayIndex: 8, thumb: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=400' },
  { id: 'SF-095', title: 'Brand Film Exotic', client: 'Sarto Imóveis', stage: 'Color', progress: 60, priority: 'Normal', deadline: '05 Nov', dayIndex: 16, thumb: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=80&w=400' },
  { id: 'SF-102', title: 'Doc Corporate', client: 'Banco Legacy', stage: 'Roteiro', progress: 25, priority: 'Urgente', deadline: '30 Out', dayIndex: 10, thumb: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=400' },
  { id: 'SF-108', title: 'Tour 360', client: 'Vértice Arq', stage: 'Captação', progress: 45, priority: 'Normal', deadline: '12 Nov', dayIndex: 23, thumb: 'https://images.unsplash.com/photo-1449156001931-828320f3a002?auto=format&fit=crop&q=80&w=400' },
];

const initialTasks: ProjectTask[] = [
  { id: 'TK-01', projectId: 'SF-092', title: 'Finalizar Color Grading (Cena 04)', assignee: 'Vitor S.', status: 'Em Andamento', priority: 'Crítica', dueDate: 'Hoje' },
  { id: 'TK-02', projectId: 'SF-092', title: 'Aprovação de Trilha Atmos', assignee: 'Rodrigo S.', status: 'Pendente', priority: 'Urgente', dueDate: 'Amanhã' },
  { id: 'TK-03', projectId: 'SF-095', title: 'Ajuste de Exposição - Drone', assignee: 'Vitor S.', status: 'Concluído', priority: 'Normal', dueDate: '23 Out' },
  { id: 'TK-04', projectId: 'SF-102', title: 'Entrevista com CEO Legacy', assignee: 'Bia L.', status: 'Pendente', priority: 'Normal', dueDate: '26 Out' },
  { id: 'TK-05', projectId: 'SF-108', title: 'Setup de Câmera 360', assignee: 'Caio M.', status: 'Em Andamento', priority: 'Urgente', dueDate: 'Hoje' },
];

export const SquadHub: React.FC = () => {
  const [tasks, setTasks] = useState<ProjectTask[]>(initialTasks);
  const [taskFilter, setTaskFilter] = useState<'Todas' | 'Pendente' | 'Em Andamento' | 'Concluído'>('Todas');

  const filteredTasks = taskFilter === 'Todas' ? tasks : tasks.filter(t => t.status === taskFilter);

  // Janela de 30 dias. Hoje é index 4.
  const todayIndex = 4; 

  return (
    <div className="space-y-10 reveal active pb-20">
      {/* Platform Header */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 border-b border-white/5 pb-8">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-3 px-3 py-1 rounded-full bg-squad-blue/5 border border-squad-blue/20">
            <span className="w-1.5 h-1.5 rounded-full bg-squad-blue animate-pulse"></span>
            <span className="text-[8px] font-black text-squad-blue uppercase tracking-widest">SQUAD HUB v2.8 // OPERATIONAL</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold uppercase tracking-tighter text-white leading-none">
            Overview <span className="font-serif italic font-normal text-gray-500">Central</span>
          </h1>
        </div>
        
        <div className="flex items-center gap-4">
          <button className="glass-card px-6 py-3 rounded-full text-[9px] font-black uppercase tracking-widest text-white hover:bg-white hover:text-black transition-all">
            Novo Projeto
          </button>
          <div className="glass-card px-5 py-3 rounded-2xl flex items-center gap-3 bg-white/5 border-white/10">
            <span className="material-symbols-outlined text-squad-blue text-lg">calendar_today</span>
            <div>
              <p className="text-[8px] text-gray-500 font-black uppercase">24 OUT 2024</p>
            </div>
          </div>
        </div>
      </div>

      {/* Grid de Métricas */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className="glass-card p-6 rounded-[2rem] border border-white/5 hover:border-squad-blue/20 transition-all group">
            <div className="flex justify-between items-start mb-6">
              <span className={`material-symbols-outlined ${stat.color} text-2xl`}>{stat.icon}</span>
              <span className="text-[8px] text-gray-600 font-black uppercase tracking-widest">{stat.detail}</span>
            </div>
            <h4 className="text-[8px] text-gray-500 font-black uppercase tracking-widest mb-1">{stat.label}</h4>
            <span className="text-3xl font-bold text-white tracking-tighter">{stat.value}</span>
          </div>
        ))}
      </div>

      {/* OVERVIEW DOS PROJETOS - NOVA SEÇÃO */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500">Status da Produção Ativa</h3>
          <button className="text-[9px] font-black text-squad-blue uppercase hover:underline">Ver Todos</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {projects.map((p) => (
            <div key={p.id} className="glass-card p-5 rounded-3xl border-white/5 hover:border-squad-blue/20 transition-all group overflow-hidden relative">
              <div className="flex gap-4 items-center">
                <div className="w-16 h-16 rounded-2xl overflow-hidden border border-white/10 flex-shrink-0">
                  <img src={p.thumb} alt={p.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-[8px] text-squad-blue font-black uppercase truncate">{p.client}</span>
                    <span className={`text-[7px] font-black uppercase px-1.5 py-0.5 rounded border ${
                      p.priority === 'Crítica' ? 'text-red-500 border-red-500/20 bg-red-500/5' : 'text-gray-500 border-white/10'
                    }`}>{p.priority}</span>
                  </div>
                  <h4 className="text-[11px] font-bold text-white uppercase truncate group-hover:text-squad-blue transition-colors">{p.title}</h4>
                  <p className="text-[8px] text-gray-600 font-black uppercase mt-1">{p.stage}</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <div className="flex justify-between text-[7px] font-black uppercase text-gray-500">
                  <span>Progresso</span>
                  <span>{p.progress}%</span>
                </div>
                <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-squad-blue shadow-[0_0_8px_rgba(0,163,211,0.5)]" style={{ width: `${p.progress}%` }}></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* COMPACT TIMELINE CARD */}
      <div className="glass-card p-8 rounded-[2.5rem] border-white/5 overflow-hidden">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-squad-blue/10 flex items-center justify-center">
              <span className="material-symbols-outlined text-squad-blue">timeline</span>
            </div>
            <div>
              <h3 className="text-lg font-black uppercase tracking-tight text-white">Timeline Mensal</h3>
              <p className="text-[9px] text-gray-600 font-black uppercase tracking-widest">Próximas Entregas</p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-squad-blue"></span>
              <span className="text-[8px] text-gray-500 font-black uppercase">Final</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-white/20"></span>
              <span className="text-[8px] text-gray-500 font-black uppercase">Hoje</span>
            </div>
          </div>
        </div>

        <div className="relative h-24 mt-12 mb-4">
          {/* Timeline Axis */}
          <div className="absolute top-1/2 left-0 w-full h-[1px] bg-white/10 -translate-y-1/2"></div>
          
          {/* Today Cursor */}
          <div 
            className="absolute top-0 bottom-0 w-[1px] bg-squad-blue/40 z-10"
            style={{ left: `${(todayIndex / 30) * 100}%` }}
          >
            <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[8px] font-black text-squad-blue uppercase bg-black px-2">Agora</div>
          </div>

          {/* Project Points */}
          {projects.map((p, i) => {
            const pos = (p.dayIndex / 30) * 100;
            const isTop = i % 2 === 0;
            return (
              <div 
                key={p.id} 
                className="absolute group"
                style={{ left: `${pos}%`, top: '50%', transform: 'translate(-50%, -50%)' }}
              >
                {/* Visual Anchor */}
                <div className={`w-3 h-3 rounded-full border border-black z-20 transition-all ${
                  p.priority === 'Crítica' ? 'bg-red-500' : 'bg-squad-blue'
                } group-hover:scale-125`}></div>

                {/* Compact Label */}
                <div className={`absolute left-1/2 -translate-x-1/2 w-32 pointer-events-none transition-all duration-500 opacity-60 group-hover:opacity-100 ${
                  isTop ? '-top-10' : 'top-6'
                }`}>
                  <div className="text-center">
                    <p className="text-[8px] font-bold text-white uppercase truncate">{p.title}</p>
                    <p className="text-[7px] text-gray-500 font-black uppercase tracking-tighter">{p.deadline}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Task Management */}
        <div className="lg:col-span-8 space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-black uppercase tracking-tight text-white">Tarefas Operacionais</h3>
            <div className="flex gap-1 bg-white/5 p-1 rounded-xl border border-white/5">
              {(['Todas', 'Pendente', 'Em Andamento', 'Concluído'] as const).map(f => (
                <button 
                  key={f}
                  onClick={() => setTaskFilter(f)}
                  className={`px-3 py-1.5 text-[8px] font-black uppercase tracking-widest rounded-lg transition-all ${taskFilter === f ? 'bg-white text-black' : 'text-gray-500 hover:text-white'}`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            {filteredTasks.map((task) => (
              <div key={task.id} className="glass-card p-5 rounded-2xl border-white/5 hover:bg-white/5 transition-all flex items-center gap-6 group">
                <div className="flex items-center gap-4 w-1/3">
                  <div className={`w-1 h-8 rounded-full ${
                    task.status === 'Concluído' ? 'bg-green-500' : 
                    task.status === 'Em Andamento' ? 'bg-squad-blue' : 'bg-gray-800'
                  }`}></div>
                  <div className="min-w-0">
                    <h5 className="text-[11px] font-bold text-white uppercase truncate">{task.title}</h5>
                    <p className="text-[8px] text-gray-600 font-black uppercase">{task.projectId}</p>
                  </div>
                </div>

                <div className="flex-1 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-squad-blue/10 border border-squad-blue/20 flex items-center justify-center text-[8px] font-black text-squad-blue">
                      {task.assignee[0]}
                    </div>
                    <span className="text-[9px] text-gray-500 font-black uppercase">{task.assignee}</span>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <span className="text-[9px] text-white font-bold">{task.dueDate}</span>
                    <button className="material-symbols-outlined text-gray-700 group-hover:text-white transition-colors text-lg">check_circle</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Status Panel */}
        <div className="lg:col-span-4 glass-card p-8 rounded-[2.5rem] border-white/5">
          <h3 className="text-lg font-black uppercase tracking-tight text-white mb-8">Recursos Ativos</h3>
          <div className="space-y-6">
            {[
              { label: 'Editores', val: 92, color: 'bg-squad-blue' },
              { label: 'Storage', val: 78, color: 'bg-purple-500' },
              { label: 'IA Load', val: 30, color: 'bg-green-500' },
            ].map(item => (
              <div key={item.label} className="space-y-2">
                <div className="flex justify-between text-[9px] font-black uppercase">
                  <span className="text-gray-500">{item.label}</span>
                  <span className="text-white">{item.val}%</span>
                </div>
                <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                  <div className={`h-full ${item.color}`} style={{ width: `${item.val}%` }}></div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-10 p-5 rounded-2xl bg-squad-blue/5 border border-squad-blue/10 text-center">
            <p className="text-[8px] text-squad-blue font-black uppercase mb-1">Health Index</p>
            <span className="text-xl font-bold text-white tracking-tighter uppercase">Optimal</span>
          </div>
        </div>
      </div>
    </div>
  );
};
