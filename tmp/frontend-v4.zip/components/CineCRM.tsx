
import React, { useState } from 'react';
import { Lead } from '../types';

const leads: Lead[] = [
  { id: 'LD-001', company: 'Sarto Luxury Broker', decisor: 'Ricardo Sarto', value: 'R$ 45.000', score: 98, status: 'Proposta' },
  { id: 'LD-002', company: 'Lugasa Empreendimentos', decisor: 'Ana Luiza', value: 'R$ 120.000', score: 92, status: 'Qualificação' },
  { id: 'LD-003', company: 'Haras da Matta', decisor: 'Marcos Paulo', value: 'R$ 32.000', score: 85, status: 'Inbound' },
  { id: 'LD-004', company: 'Vértice Arquitetura', decisor: 'Carlos Vértice', value: 'R$ 65.000', score: 78, status: 'Inbound' },
  { id: 'LD-005', company: 'Gourmet Garden', decisor: 'Felipe Chef', value: 'R$ 28.000', score: 95, status: 'Fechado' },
];

const statusColumns = ['Inbound', 'Qualificação', 'Proposta', 'Fechado'];

export const CineCRM: React.FC = () => {
  const [filter, setFilter] = useState<string>('Todos');

  return (
    <div className="space-y-12 reveal active pb-20">
      {/* Header do Módulo */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 border-b border-white/5 pb-10">
        <div className="space-y-3">
          <div className="inline-flex items-center gap-3 px-3 py-1 rounded-full bg-squad-blue/5 border border-squad-blue/20">
            <span className="material-symbols-outlined text-squad-blue text-[14px]">radar</span>
            <span className="text-[9px] font-black text-squad-blue uppercase tracking-widest">Cine-Scout Active // Enriquecimento de Dados Ativo</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold uppercase tracking-tighter text-white">
            Cine <span className="font-serif italic font-normal text-gray-500">CRM</span>
          </h1>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="relative group">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 material-symbols-outlined text-gray-500 group-hover:text-white transition-colors">search</span>
            <input 
              type="text" 
              placeholder="Buscar conta ou decisor..." 
              className="glass-card bg-white/5 rounded-full pl-12 pr-6 py-4 text-[10px] font-black uppercase tracking-widest text-white placeholder-gray-600 focus:outline-none focus:border-squad-blue transition-all w-64 md:w-80"
            />
          </div>
          <button className="glass-card px-8 py-4 rounded-full text-[10px] font-black uppercase tracking-widest text-white hover:bg-white hover:text-black transition-all">
            Novo Lead
          </button>
        </div>
      </div>

      {/* Pipeline View (Horizontal Scrollable on Mobile) */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 min-h-[600px]">
        {statusColumns.map((col) => (
          <div key={col} className="space-y-6 flex flex-col">
            <div className="flex items-center justify-between px-4 pb-2 border-b border-white/5">
              <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{col}</span>
              <span className="w-6 h-6 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-[10px] font-black text-white">
                {leads.filter(l => l.status === col).length}
              </span>
            </div>
            
            <div className="flex-1 space-y-4">
              {leads.filter(l => l.status === col).map((lead) => (
                <div 
                  key={lead.id} 
                  className="glass-card p-8 rounded-[2rem] border-white/5 hover:border-squad-blue/30 transition-all duration-500 group cursor-pointer relative overflow-hidden"
                >
                  {/* AI Score Indicator */}
                  <div className={`absolute top-0 right-0 w-1 h-full ${lead.score > 90 ? 'bg-green-500' : 'bg-squad-blue/30'}`}></div>
                  
                  <div className="flex justify-between items-start mb-6">
                    <span className="text-[9px] text-gray-600 font-black uppercase">{lead.id}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold text-white">{lead.score}</span>
                      <span className="material-symbols-outlined text-squad-blue text-[14px]">auto_awesome</span>
                    </div>
                  </div>

                  <h4 className="text-lg font-bold text-white uppercase tracking-tight mb-2 group-hover:text-squad-blue transition-colors">{lead.company}</h4>
                  <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest mb-6">{lead.decisor}</p>
                  
                  <div className="flex justify-between items-end pt-6 border-t border-white/5">
                    <div>
                      <p className="text-[9px] text-gray-600 uppercase font-black">Ticket Estimado</p>
                      <p className="text-xs text-white font-bold">{lead.value}</p>
                    </div>
                    <button className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-gray-600 group-hover:text-white transition-all">
                      <span className="material-symbols-outlined text-sm">arrow_forward</span>
                    </button>
                  </div>
                </div>
              ))}
              
              {/* Empty State / Add Placeholder */}
              <button className="w-full py-10 border-2 border-dashed border-white/5 rounded-[2rem] text-gray-700 hover:border-squad-blue/20 hover:text-gray-400 transition-all flex flex-col items-center justify-center gap-2">
                <span className="material-symbols-outlined">add</span>
                <span className="text-[9px] font-black uppercase tracking-widest">Adicionar Lead</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* IA Insights Section for CRM */}
      <div className="glass-card p-10 rounded-[3rem] border border-squad-blue/10 bg-gradient-to-br from-[#080808] to-black">
        <div className="flex items-center gap-6 mb-10">
          <div className="w-16 h-16 rounded-3xl bg-squad-blue/10 border border-squad-blue/20 flex items-center justify-center">
            <span className="material-symbols-outlined text-squad-blue text-4xl animate-pulse">psychology</span>
          </div>
          <div>
            <h3 className="text-2xl font-black uppercase tracking-tighter text-white">Próximas Ações Sugeridas pela IA</h3>
            <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest mt-1">Análise baseada em interações via WhatsApp e Email</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            { target: 'Sarto Luxury', action: 'Enviar áudio ElevenLabs', reason: 'Lead muito engajado no portfólio de tour 360.', time: 'Prioridade 1' },
            { target: 'Lugasa Group', action: 'Agendar Call Diagnóstico', reason: 'Decisor demonstrou urgência em vídeo de lançamento.', time: 'Prioridade 1' },
            { target: 'Vértice Arq', action: 'Follow-up de portfólio', reason: 'Visualizou o PDF de proposta 3 vezes na última hora.', time: 'Prioridade 2' },
          ].map((insight, i) => (
            <div key={i} className="p-8 rounded-[2rem] bg-white/5 border border-white/5 hover:bg-white/10 transition-all group">
              <div className="flex justify-between mb-4">
                <span className="text-[10px] text-squad-blue font-black uppercase tracking-widest">{insight.time}</span>
                <span className="material-symbols-outlined text-gray-700">more_horiz</span>
              </div>
              <h5 className="text-white font-bold uppercase mb-2">{insight.target}</h5>
              <p className="text-xs text-gray-400 font-serif italic mb-6 leading-relaxed">"{insight.reason}"</p>
              <button className="w-full py-4 bg-squad-blue/10 text-squad-blue rounded-xl text-[10px] font-black uppercase tracking-widest border border-squad-blue/20 group-hover:bg-squad-blue group-hover:text-white transition-all">
                Executar: {insight.action}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
