
import React from 'react';

interface NavbarProps {
  view: 'landing' | 'hub';
  setView: (view: 'landing' | 'hub') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ view, setView }) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-white/5 py-6 px-6 md:px-12 flex flex-col md:flex-row items-center justify-between gap-6 bg-black/40 backdrop-blur-3xl">
      <div className="flex items-center gap-10">
        <a className="flex items-center gap-2 group pointer-events-auto" href="#" onClick={() => setView('landing')}>
          <span className="material-symbols-outlined text-squad-blue group-hover:rotate-180 transition-transform duration-700" style={{ fontSize: '28px' }}>stars</span>
          <span className="font-bold text-xl tracking-tighter font-serif italic text-white">SQUAD {view === 'hub' ? 'Hub' : 'Film'}</span>
        </a>
        <div className="hidden lg:block border-l border-white/10 pl-10">
          <p className="text-[10px] text-gray-500 max-w-[280px] leading-relaxed uppercase tracking-widest font-medium">
            <span className="text-white font-black">{view === 'hub' ? 'Plataforma Operacional' : 'Project Showcase'}</span> — Inteligência Central da Produção Cinematográfica de Luxo.
          </p>
        </div>
      </div>
      
      <nav className="flex items-center gap-1 bg-white/5 rounded-full p-1 border border-white/10 pointer-events-auto shadow-2xl">
        <button 
          onClick={() => setView('landing')}
          className={`px-6 py-2 text-[10px] font-black rounded-full uppercase tracking-widest transition-all duration-500 ${view === 'landing' ? 'bg-white text-black' : 'text-gray-400 hover:text-white'}`}
        >
          Showcase
        </button>
        <button 
          onClick={() => setView('hub')}
          className={`px-6 py-2 text-[10px] font-black rounded-full uppercase tracking-widest transition-all duration-500 ${view === 'hub' ? 'bg-white text-black shadow-2xl' : 'text-gray-400 hover:text-white'}`}
        >
          SQUAD Hub
        </button>
      </nav>
    </header>
  );
};
