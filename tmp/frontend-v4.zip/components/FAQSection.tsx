
import React from 'react';

const faqs = [
  "Quais serviços vocês oferecem?",
  "Vocês atendem fora de Brasília e Goiânia?",
  "Vocês fazem estratégia de marketing também?",
  "Vocês fazem Tour Virtual 360° e Tela Interativa?",
  "O que inclui o Kit Lançamento Imobiliário?",
  "Como funciona o processo de trabalho?"
];

export const FAQSection: React.FC = () => {
  return (
    <section id="faq" className="py-24 border-t border-white/5">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div>
          <span className="text-xs font-mono text-gray-500 mb-6 block uppercase tracking-widest">FAQ .</span>
          <h2 className="text-5xl font-display font-medium leading-none">Dúvidas<br/><span className="font-serif italic text-gray-400">Frequentes</span></h2>
        </div>
        <div className="space-y-4">
          {faqs.map((q, i) => (
            <div key={i} className="border-b border-white/5 py-6 flex justify-between items-center group cursor-pointer">
              <span className="text-gray-500 font-mono text-xs mr-6">0{i+1}</span>
              <span className="text-lg text-gray-300 group-hover:text-white transition-colors flex-1">{q}</span>
              <span className="material-symbols-outlined text-gray-600 group-hover:rotate-45 transition-transform">add</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
