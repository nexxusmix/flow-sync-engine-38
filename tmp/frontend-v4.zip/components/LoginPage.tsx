
import React, { useState } from 'react';

interface LoginPageProps {
  onLogin: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isHovering, setIsHovering] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Credenciais solicitadas: matheus.fellip@hotmail.com / Math@.13
    if (email === 'matheus.fellip@hotmail.com' && password === 'Math@.13') {
      setError('');
      onLogin();
    } else {
      setError('Credenciais de estúdio inválidas. Tente novamente.');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black flex items-center justify-center overflow-hidden font-sans">
      {/* Background Cinematic Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-[-20%] left-[-10%] w-[1000px] h-[1000px] bg-squad-blue/10 blur-[180px] rounded-full animate-float"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[800px] h-[800px] bg-white/5 blur-[150px] rounded-full animate-float" style={{ animationDelay: '-4s' }}></div>
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-overlay"></div>
      </div>

      <div className="relative z-10 w-full max-w-xl px-6 reveal active">
        {/* Branding */}
        <div className="text-center mb-16 space-y-4">
          <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full border border-white/5 bg-white/5 backdrop-blur-xl mb-4">
            <span className="material-symbols-outlined text-squad-blue text-sm animate-pulse">lock</span>
            <span className="text-[9px] font-black text-white/60 uppercase tracking-[0.5em]">Acesso Restrito // Studio Root</span>
          </div>
          <h1 className="text-6xl md:text-8xl font-extrabold text-white uppercase tracking-tighter leading-none">
            SQUAD <span className="font-serif italic font-normal text-gray-500">Hub</span>
          </h1>
          <p className="text-gray-500 text-[10px] uppercase tracking-[0.4em] font-bold">Inteligência Cinematográfica & Gestão de Luxo</p>
        </div>

        {/* Login Card */}
        <div className="glass-card p-12 md:p-16 rounded-[4rem] border-white/5 bg-black/40 backdrop-blur-3xl shadow-[0_100px_100px_-50px_rgba(0,0,0,0.9)]">
          <form onSubmit={handleSubmit} className="space-y-10">
            <div className="space-y-6">
              <div className="group relative">
                <label className="absolute -top-3 left-6 px-2 bg-[#050505] text-[8px] font-black text-squad-blue uppercase tracking-widest z-10">Identificação (Email)</label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder="matheus.fellip@hotmail.com"
                  className={`w-full bg-white/5 border ${error ? 'border-red-500/50' : 'border-white/10'} rounded-2xl px-8 py-5 text-sm text-white focus:outline-none focus:border-squad-blue/50 transition-all placeholder:text-gray-800`}
                  required
                />
              </div>

              <div className="group relative">
                <label className="absolute -top-3 left-6 px-2 bg-[#050505] text-[8px] font-black text-squad-blue uppercase tracking-widest z-10">Chave de Acesso</label>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder="••••••••"
                  className={`w-full bg-white/5 border ${error ? 'border-red-500/50' : 'border-white/10'} rounded-2xl px-8 py-5 text-sm text-white focus:outline-none focus:border-squad-blue/50 transition-all placeholder:text-gray-800`}
                  required
                />
              </div>

              {error && (
                <div className="px-6 py-3 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center gap-3 animate-pulse">
                  <span className="material-symbols-outlined text-red-500 text-sm">error</span>
                  <span className="text-[10px] font-black text-red-500 uppercase tracking-widest">{error}</span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between px-2">
              <label className="flex items-center gap-3 cursor-pointer group">
                <div className="w-4 h-4 rounded border border-white/10 flex items-center justify-center group-hover:border-squad-blue transition-colors">
                  <div className="w-2 h-2 bg-squad-blue rounded-sm opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
                <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest group-hover:text-white transition-colors">Lembrar neste terminal</span>
              </label>
              <a href="#" className="text-[9px] font-black text-gray-500 uppercase tracking-widest hover:text-squad-blue transition-colors underline underline-offset-4">Resetar Credenciais</a>
            </div>

            <button 
              type="submit"
              onMouseEnter={() => setIsHovering(true)}
              onMouseLeave={() => setIsHovering(false)}
              className="relative w-full py-6 rounded-full bg-white text-black font-black uppercase text-[11px] tracking-[0.4em] overflow-hidden transition-all hover:scale-[1.02] active:scale-[0.98] shadow-2xl"
            >
              <span className={`relative z-10 transition-transform duration-500 ${isHovering ? '-translate-y-12 block opacity-0' : 'block opacity-100'}`}>Entrar no Estúdio</span>
              <span className={`absolute inset-0 flex items-center justify-center transition-transform duration-500 ${isHovering ? 'translate-y-0 opacity-100' : 'translate-y-12 opacity-0'}`}>
                <span className="material-symbols-outlined mr-3 animate-spin">sync</span>
                Autenticando...
              </span>
            </button>
          </form>
        </div>

        {/* Footer Support */}
        <div className="mt-12 text-center">
          <p className="text-[9px] text-gray-700 font-bold uppercase tracking-[0.3em]">© 2024 SQUAD FILM GLOBAL • TODOS OS DIREITOS RESERVADOS</p>
        </div>
      </div>
      
      {/* Decorative Large Background Letters */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.02] select-none pointer-events-none">
        <span className="text-[60rem] font-black text-white leading-none tracking-tighter">SF</span>
      </div>
    </div>
  );
};
