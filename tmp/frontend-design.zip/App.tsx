
import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { SquadHub } from './components/SquadHub';
import { GeminiAssistant } from './components/GeminiAssistant';
import { ModuleType } from './types';

const App: React.FC = () => {
  const [activeModule, setActiveModule] = useState<ModuleType>('dashboard');
  const [showAssistant, setShowAssistant] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.scrollY;
      const main = document.querySelector('main');
      if (main) {
        const rotation = Math.min(scrolled * 0.003, 2);
        main.style.transform = `rotateX(${rotation}deg)`;
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-squad-blue selection:text-white overflow-x-hidden transition-colors duration-1000 flex">
      <Sidebar activeModule={activeModule} setModule={setActiveModule} />

      <main className="flex-1 ml-20 md:ml-64 relative z-10 pt-20 px-6 md:px-12 max-w-[1800px] mx-auto pb-40 transition-all duration-1000 ease-out preserve-3d">
        {/* Module Content Switch */}
        {activeModule === 'dashboard' && <SquadHub />}
        
        {activeModule !== 'dashboard' && (
          <div className="min-h-[60vh] flex flex-col items-center justify-center text-center space-y-6 reveal active">
             <span className="material-symbols-outlined text-squad-blue text-6xl animate-pulse">construction</span>
             <h2 className="text-4xl font-extrabold uppercase tracking-tighter">Módulo em <br/><span className="font-serif italic text-gray-500 font-normal">Implementação</span></h2>
             <p className="text-gray-600 max-w-sm font-medium uppercase tracking-[0.2em] text-[10px]">Aguardando conexão com o backend e validação de fluxo de IA Agente.</p>
             <button 
              onClick={() => setActiveModule('dashboard')}
              className="px-10 py-4 border border-white/10 rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-white hover:text-black transition-all"
             >
               Voltar para Dashboard
             </button>
          </div>
        )}
      </main>

      {/* Floating AI Agent Trigger */}
      <button 
        onClick={() => setShowAssistant(!showAssistant)}
        className="fixed bottom-12 right-12 z-50 p-8 bg-squad-blue text-white rounded-[2rem] shadow-[0_30px_90px_-10px_rgba(0,163,211,0.7)] hover:scale-110 active:scale-90 transition-all duration-700 group"
      >
        <div className="flex items-center gap-4">
          <span className="material-symbols-outlined text-4xl">auto_awesome</span>
          <span className="hidden lg:inline font-black uppercase text-[12px] tracking-[0.4em]">IA COMMAND</span>
        </div>
      </button>

      {showAssistant && (
        <GeminiAssistant onClose={() => setShowAssistant(false)} />
      )}
    </div>
  );
};

export default App;
