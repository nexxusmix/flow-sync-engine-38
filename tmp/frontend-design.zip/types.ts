
export type ModuleType = 'dashboard' | 'crm' | 'production' | 'financial' | 'ai-agents' | 'settings';

export interface Lead {
  id: string;
  company: string;
  decisor: string;
  value: string;
  score: number;
  status: 'Inbound' | 'Qualificação' | 'Proposta' | 'Fechado';
}

export interface ProductionProject {
  id: string;
  title: string;
  client: string;
  stage: 'Briefing' | 'Roteiro' | 'Set' | 'Edição' | 'Review';
  progress: number;
  priority: 'Baixa' | 'Normal' | 'Urgente' | 'Crítica';
}

export interface AITask {
  agent: 'SDR' | 'PM' | 'QA' | 'Fin';
  message: string;
  timestamp: string;
  actionRequired: boolean;
}

// Added missing Experience export used by components/ExperienceSection.tsx to fix compilation errors
export interface Experience {
  id: string;
  role: string;
  company: string;
  period: string;
  type: string;
}
