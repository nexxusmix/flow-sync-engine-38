
import React from 'react';

const stats = [
  { label: 'Pipeline Ativo', value: 'R$ 840k', detail: '+15.2%', icon: 'insights', color: 'text-squad-blue' },
  { label: 'Projetos em Workflow', value: '12', detail: '87% On-time', icon: 'schedule', color: 'text-white' },
  { label: 'Inadimplência', value: '0.42%', detail: 'Low Risk', icon: 'shield', color: 'text-green-500' },
  { label: 'Tokens IA', value: '1.2M', detail: 'Consumo Mensal', icon: 'memory', color: 'text-purple-400' },
];

export const SquadHub: React.FC = () => {
  return (
    <div className="space-y-16 reveal active">
      {/* Platform Header */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 border-b border-white/5 pb-10">
        <div className="space-y-3">
          <div className="inline-flex items-center gap-3 px-3 py-1 rounded-full bg-squad-blue/5 border border-squad-blue/20">
            <span className="w-2 h-2 rounded-full bg-squad-blue animate-pulse"></span>
            <span className="text-[9px] font-black text-squad-blue uppercase tracking-widest">Single Source of Truth // Alpha v2.4</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold uppercase tracking-tighter text-white">
            Overview <span className="font-serif italic font-normal text-gray-500">Central</span>
          </h1>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="glass-card px-6 py-4 rounded-2xl flex items-center gap-4 bg-white/5">
            <span className="material-symbols-outlined text-squad-blue">calendar_today</span>
            <div>
              <p className="text-[9px] text-gray-500 font-black uppercase">Data Atual</p>
              <p className="text-xs text-white font-bold">24 OUT 2024</p>
            </div>
          </div>
        </div>
      </div>

      {/* Grid de Métricas High-End */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="glass-card p-10 rounded-[2.5rem] border border-white/5 hover:border-squad-blue/20 transition-all duration-700 group cursor-default">
            <div className="flex justify-between items-start mb-10">
              <span className={`material-symbols-outlined ${stat.color} text-4xl`}>{stat.icon}</span>
              <span className="text-[10px] text-gray-600 font-black uppercase tracking-widest">{stat.detail}</span>
            </div>
            <h4 className="text-[10px] text-gray-500 font-black uppercase tracking-[0.4em] mb-3">{stat.label}</h4>
            <span className="text-5xl font-bold text-white tracking-tighter">{stat.value}</span>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Terminal de Atividades Críticas */}
        <div className="lg:col-span-8 space-y-8">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-black uppercase tracking-tighter text-white">Próximos Marcos de Produção</h3>
            <button className="text-[10px] text-squad-blue font-black uppercase tracking-widest hover:text-white transition-colors">Visualizar Cronograma</button>
          </div>
          
          <div className="space-y-4">
            {[
              { id: 'SF-092', title: 'Manifesto Residencial Matta', client: 'Lugasa Group', stage: 'Review 4K', status: 'priority_high' },
              { id: 'SF-095', title: 'Brand Film Exotic', client: 'Sarto Imóveis', stage: 'Color Grading', status: 'schedule' },
              { id: 'SF-102', title: 'Documentário Corporate', client: 'Banco Legacy', stage: 'Roteiro Final', status: 'check_circle' },
            ].map((p, i) => (
              <div key={i} className="glass-card p-8 rounded-[2rem] border-white/5 flex items-center justify-between hover:bg-white/5 transition-all">
                <div className="flex items-center gap-6">
                  <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-gray-600 font-black text-[10px]">
                    {p.id}
                  </div>
                  <div>
                    <h5 className="text-lg font-bold text-white uppercase tracking-tight">{p.title}</h5>
                    <p className="text-[10px] text-gray-500 uppercase font-black">{p.client}</p>
                  </div>
                </div>
                <div className="flex items-center gap-10">
                  <div className="text-right">
                    <span className="text-[10px] text-gray-600 block uppercase font-black">Etapa Atual</span>
                    <span className="text-white font-bold">{p.stage}</span>
                  </div>
                  <span className={`material-symbols-outlined ${i === 0 ? 'text-squad-blue' : 'text-gray-700'}`}>{p.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Command Center Side Panel */}
        <div className="lg:col-span-4 space-y-8">
          <div className="glass-card p-10 rounded-[3rem] bg-gradient-to-br from-[#080808] to-black border-squad-blue/10 flex flex-col h-full">
            <div className="flex items-center gap-5 mb-12">
              <span className="material-symbols-outlined text-squad-blue animate-pulse text-4xl">auto_awesome</span>
              <div>
                <h3 className="text-xl font-black uppercase tracking-tighter text-white">IA Intelligence</h3>
                <span className="text-[9px] text-gray-600 font-black uppercase tracking-widest">Active Monitoring</span>
              </div>
            </div>

            <div className="space-y-8 flex-1">
              <div className="p-6 rounded-3xl bg-white/5 border border-white/5 relative">
                <div className="absolute top-4 right-4 flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-squad-blue opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-squad-blue"></span>
                </div>
                <p className="text-[11px] text-gray-400 font-serif italic leading-relaxed mb-6">
                  "Agente SDR detectou inércia de 48h no Lead Sarto Luxury. Sugiro envio de áudio via Voice AI ElevenLabs personalizado."
                </p>
                <div className="flex gap-3">
                  <button className="px-6 py-2.5 bg-squad-blue text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:scale-105 transition-all">Ativar SDR</button>
                  <button className="px-6 py-2.5 bg-white/5 text-gray-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:text-white transition-all">Pular</button>
                </div>
              </div>

              <div className="p-6 rounded-3xl bg-white/5 border border-white/5 opacity-50">
                <p className="text-[11px] text-gray-500 font-serif italic leading-relaxed">
                  "Relatório PM: O projeto Residencial Matta está 15% acima da margem prevista. Recomendação de upsell em Reels."
                </p>
              </div>
            </div>

            <div className="mt-12 pt-8 border-t border-white/5">
              <div className="flex justify-between items-center text-[10px] font-black uppercase text-gray-600 mb-3">
                <span>Carga de Processamento</span>
                <span className="text-white">64%</span>
              </div>
              <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-squad-blue w-[64%]"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
