
import React from 'react';
import { ModuleType } from '../types';

interface SidebarProps {
  activeModule: ModuleType;
  setModule: (module: ModuleType) => void;
}

const menuItems = [
  { id: 'dashboard', icon: 'dashboard', label: 'Overview' },
  { id: 'crm', icon: 'radar', label: 'Cine CRM' },
  { id: 'production', icon: 'movie_edit', label: 'Produção' },
  { id: 'ai-agents', icon: 'auto_awesome', label: 'IA Agents' },
  { id: 'financial', icon: 'account_balance_wallet', label: 'Financeiro' },
  { id: 'settings', icon: 'settings', label: 'Configurações' },
];

export const Sidebar: React.FC<SidebarProps> = ({ activeModule, setModule }) => {
  return (
    <aside className="fixed left-0 top-0 h-screen w-20 md:w-64 bg-[#050505] border-r border-white/5 z-50 flex flex-col items-center md:items-start py-10 transition-all duration-500">
      <div className="px-6 mb-16 flex items-center gap-3 w-full">
        <span className="material-symbols-outlined text-squad-blue text-3xl">stars</span>
        <span className="hidden md:block font-serif italic text-xl font-bold tracking-tighter text-white">SQUAD Hub</span>
      </div>

      <nav className="flex-1 w-full space-y-2 px-3">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setModule(item.id as ModuleType)}
            className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl transition-all duration-300 group ${
              activeModule === item.id 
                ? 'bg-white text-black shadow-[0_10px_30px_rgba(255,255,255,0.1)]' 
                : 'text-gray-500 hover:text-white hover:bg-white/5'
            }`}
          >
            <span className={`material-symbols-outlined ${activeModule === item.id ? 'text-black' : 'text-gray-400 group-hover:text-squad-blue'}`}>
              {item.icon}
            </span>
            <span className="hidden md:block text-[10px] font-black uppercase tracking-widest">
              {item.label}
            </span>
          </button>
        ))}
      </nav>

      <div className="px-6 py-10 border-t border-white/5 w-full">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-squad-blue/20 flex items-center justify-center text-squad-blue text-xs font-black">
            RS
          </div>
          <div className="hidden md:block">
            <p className="text-[10px] text-white font-black uppercase">Rodrigo S.</p>
            <p className="text-[9px] text-gray-600 font-bold uppercase tracking-tighter">Admin Root</p>
          </div>
        </div>
      </div>
    </aside>
  );
};
